<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Company\\Providers\\CompanyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Company\\Providers\\CompanyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);