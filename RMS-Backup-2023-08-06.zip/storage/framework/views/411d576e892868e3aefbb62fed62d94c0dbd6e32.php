<?php echo $__env->make('company::layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php

foreach ($other_details as $other_detail)  {
    $name = $other_detail->name;
    $phone = $other_detail->phone;
}
foreach ($login_details as $login_details)  {
    $status = $login_details->status;
    $email =$login_details->email;
    if($status == "active"){
    $check = "checked";
    }
    else{
        $check = "";
    }
}
?>
<div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">

                <div class="row mt-4">
                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Edit Admin</h4>
                                <?php if(Session::has('success')): ?> <div class="alert alert-success mt-2 mb-2"><?php echo e(Session::get('success')); ?></li></div><?php endif; ?>
                                <?php if(Session::has('fail')): ?> <div class="alert alert-danger mt-2 mb-2"><?php echo e(Session::get('fail')); ?></li></div><?php endif; ?>
                            </div><!--end card-header-->
                            <div class="card-body">
                                <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Name</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name" value="<?php echo e($name); ?>">
                                        <?php if($errors->has("name")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('name')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Email</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" value="<?php echo e($email); ?>">
                                        <?php if($errors->has("email")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('email')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Phone No</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="phone" value="<?php echo e($phone); ?>">
                                        <?php if($errors->has("phone")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('phone')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1">Current Password</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" name="current_password">
                                        <?php if($errors->has("current_password")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('current_password')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1">New Password</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" name="password">
                                        <?php if($errors->has("password")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('password')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1">Confirm Password</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" name="password_confirmation">
                                        <?php if($errors->has("password_confirmation")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('password_confirmation')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="InlineCheckbox" data-parsley-multiple="groups" data-parsley-mincheck="2" name="status" <?php echo e($check); ?>>
                                            <label class="custom-control-label" for="InlineCheckbox">Active Admin</label>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-de-primary">Submit</button>

                                </form>
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
    </div><!-- container -->
    <?php echo $__env->make('company::layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\railway-management\Modules/Company\Resources/views/edit_admin.blade.php ENDPATH**/ ?>