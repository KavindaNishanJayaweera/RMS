<?php echo $__env->make('company::layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">

                <div class="row mt-4">
                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Add Train</h4>
                                <?php if(Session::has('success')): ?> <div class="alert alert-success mt-2 mb-2"><?php echo e(Session::get('success')); ?></li></div><?php endif; ?>
                                <?php if(Session::has('fail')): ?> <div class="alert alert-danger mt-2 mb-2"><?php echo e(Session::get('fail')); ?></li></div><?php endif; ?>
                            </div><!--end card-header-->
                            <div class="card-body">
                                <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Train Name</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name">
                                        <?php if($errors->has("name")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('name')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Train Route</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="route">
                                        <?php if($errors->has("route")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('route')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Departure</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="departure">
                                        <?php if($errors->has("departure")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('departure')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Arrival</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="arrival">
                                        <?php if($errors->has("arrival")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('arrival')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Departure Time</label>
                                        <input class="form-control" type="time"  id="example-time-input" name="departure_time">
                                        <?php if($errors->has("departure_time")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('departure_time')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">No of Passengers</label>
                                        <input class="form-control" type="number"  id="example-time-input" name="no_of_passengers">
                                        <?php if($errors->has("no_of_passengers")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('no_of_passengers')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Fee (For a 1KM)</label>
                                        <input class="form-control" type="number"  id="example-time-input" name="fee">
                                        <?php if($errors->has("fee")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('fee')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="col-md-12">
                                <label for="exampleInputEmail1" class="mb-2">Train Stops</label>
                                    <div class="row">
                                       <div class="col-md-4">
                                        <div class="mb-3">
                                        <label for="exampleInputEmail1">Stop Name</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="stop_name[]" >
                                        </div>
                                        </div>
                                        <div class="col-md-4">
                                        <div class="mb-3">
                                        <label for="exampleInputEmail1">Distance (KM)</label>
                                        <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="distance[]" >
                                        </div>
                                        </div>
                                        <div class="col-md-4">

                                        <button type="button" class="btn btn-info mt-4 btn-sm" id="add_more_stops"><i class="fas fa-plus me-2"></i>Add More Stops</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12" id="dynamic_field3">
                                </div>
                                    <div class="mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="InlineCheckbox" data-parsley-multiple="groups" data-parsley-mincheck="2" name="status" checked>
                                            <label class="custom-control-label" for="InlineCheckbox">Active Train</label>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-de-primary">Submit</button>

                                </form>
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
    </div><!-- container -->
    <?php echo $__env->make('company::layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>

        $(document).ready(function(){
      var i=0;
      $('#add_more_stops').click(function(){
           i++;
           $('#dynamic_field3').append('<div class="row mb-3" id="inputFormRow3"><div class="col-md-4"><input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="stop_name[]" required></div><div class ="col-md-4"> <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="distance[]" required></div><div class ="col-md-4"> <button type="button" class="btn btn-danger btn-sm" id="delete_stop"><i class="fas fa-minus me-2"></i>Remove</button></div></div>');
      });

 });

   $(document).on('click', '#delete_stop', function () {
        $(this).closest('#inputFormRow3').remove();
    });
 </script>
<?php /**PATH C:\wamp64\www\railway-management\Modules/Company\Resources/views/add_train.blade.php ENDPATH**/ ?>