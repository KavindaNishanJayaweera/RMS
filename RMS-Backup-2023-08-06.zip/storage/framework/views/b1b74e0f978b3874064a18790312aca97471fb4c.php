<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
use App\Models\AdminDetails;
?>
<div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">

            <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Book Trains</h4>
                                <?php if(Session::has('success')): ?> <div class="alert alert-success mt-2 mb-2"><?php echo e(Session::get('success')); ?></li></div><?php endif; ?>
                                <?php if(Session::has('fail')): ?> <div class="alert alert-danger mt-2 mb-2"><?php echo e(Session::get('fail')); ?></li></div><?php endif; ?>
                            </div><!--end card-header-->
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="datatable_1">
                                        <thead class="thead-light">
                                          <tr>
                                            <th>No</th>
                                            <th>Name</th>
                                            <th>Route</th>
                                            <th>Departure</th>
                                            <th>Arrival</th>
                                            <th>No of Passengers</th>
                                            <th>Fee (For a 1KM)</th>

                                            <th>Actions</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($trains as $train) {

                                        ?>
                                            <tr>
                                                <td>#<?php echo e($train->id); ?></td>
                                                <td><?php echo e($train->name); ?></td>
                                                <td><?php echo e($train->route); ?></td>
                                                <td><?php echo e($train->departure); ?></td>
                                                <td><?php echo e($train->arrival); ?></td>
                                                <td><?php echo e($train->no_of_passengers); ?></td>
                                                <td>රු<?php echo e(number_format($train->fee)); ?></td>

                                                <td >
                                                <a href="<?php echo e(url('book-train/'.$train->id.'')); ?>"><button type="button" class="btn btn-success btn-xs">Book Train</button></a>
                                               </td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                      </table>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->
    </div><!-- container -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\railway-management\resources\views/book_trains.blade.php ENDPATH**/ ?>