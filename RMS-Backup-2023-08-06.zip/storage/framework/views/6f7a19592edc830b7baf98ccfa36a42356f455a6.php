<?php echo $__env->make('company::layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">

<!-- Page Content-->
<div class="page-content-tab">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">

                    <h4 class="page-title">Dashboard</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->


        <div class="row">
                    <div class="col-12 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col text-center">
                                        <span class="h5  fw-bold"><?php echo e($admin_count); ?></span>
                                        <h6 class="text-uppercase text-muted mt-2 m-0 font-11">No of Admins</h6>
                                        <a href="<?php echo e(url('company/all-admins')); ?>" class="btn btn-primary mt-4 btn-sm">View<i class="las la-arrow-right"></i></a>
                                    </div><!--end col-->
                                </div> <!-- end row -->
                            </div><!--end card-body-->
                        </div> <!--end card-body-->
                    </div><!--end col-->
                    <div class="col-12 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col text-center">
                                        <span class="h5  fw-bold"><?php echo e($passenger_count); ?></span>
                                        <h6 class="text-uppercase text-muted mt-2 m-0 font-11">No of Passengers</h6>
                                        <a href="<?php echo e(url('company/all-passengers')); ?>" class="btn btn-primary mt-4 btn-sm">View<i class="las la-arrow-right"></i></a>
                                    </div><!--end col-->
                                </div> <!-- end row -->
                            </div><!--end card-body-->
                        </div> <!--end card-body-->
                    </div><!--end col-->
                    <div class="col-12 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col text-center">
                                        <span class="h5  fw-bold"><?php echo e($trains_count); ?></span>
                                        <h6 class="text-uppercase text-muted mt-2 m-0 font-11">No of Trains</h6>
                                        <a href="<?php echo e(url('company/all-trains')); ?>" class="btn btn-primary mt-4 btn-sm">View<i class="las la-arrow-right"></i></a>
                                    </div><!--end col-->
                                </div> <!-- end row -->
                            </div><!--end card-body-->
                        </div> <!--end card-body-->
                    </div><!--end col-->
                    <div class="col-12 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col text-center">
                                        <span class="h5  fw-bold"><?php echo e($bookings_count); ?></span>
                                        <h6 class="text-uppercase text-muted mt-2 m-0 font-11">No of Bookings</h6>
                                        <a href="<?php echo e(url('company/booking-history')); ?>" class="btn btn-primary mt-4 btn-sm">View<i class="las la-arrow-right"></i></a>
                                    </div><!--end col-->
                                </div> <!-- end row -->
                            </div><!--end card-body-->
                        </div> <!--end card-->
                    </div><!--end col-->
                </div>

    </div><!-- container -->
    <?php echo $__env->make('company::layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\railway-management\Modules/Company\Resources/views/dashboard2.blade.php ENDPATH**/ ?>