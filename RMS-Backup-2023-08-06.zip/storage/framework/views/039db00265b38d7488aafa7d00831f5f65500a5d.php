<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
use App\Models\Trains;
use App\Models\TrainStops;
?>
<div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">

            <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">View Booking Details</h4>
                                <?php if(Session::has('success')): ?> <div class="alert alert-success mt-2 mb-2"><?php echo e(Session::get('success')); ?></li></div><?php endif; ?>
                                <?php if(Session::has('fail')): ?> <div class="alert alert-danger mt-2 mb-2"><?php echo e(Session::get('fail')); ?></li></div><?php endif; ?>
                            </div><!--end card-header-->
                            <div class="card-body">

                            <div class="row mt-4">
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Train :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e(Trains::where('id', $booking->train_id)->value('name')); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">From :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e(TrainStops::where('id', $booking->from_stop)->value('stop_name')); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">To :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e(TrainStops::where('id', $booking->to_stop)->value('stop_name')); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Date :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->date); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Tickets :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->tickets); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Total :</p>
                                </div>
                                <div class="col-md-10">
                                    <p >රු<?php echo e(number_format($booking->booking_total)); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Status :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->status); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Payment ID :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->payment_id); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Payment Method :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->method); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">First Name :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->first_name); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Last Name :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->last_name); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Email :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->email); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Phone Number :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->phone_number); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Country :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->country); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Address :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->address); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">Postal Code :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->postal_code); ?></p>
                                </div>
                                <div class="col-md-2">
                                    <p style="font-weight:bold">City :</p>
                                </div>
                                <div class="col-md-10">
                                    <p ><?php echo e($booking->city); ?></p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->
    </div><!-- container -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\railway-management\resources\views/view_booking_details.blade.php ENDPATH**/ ?>