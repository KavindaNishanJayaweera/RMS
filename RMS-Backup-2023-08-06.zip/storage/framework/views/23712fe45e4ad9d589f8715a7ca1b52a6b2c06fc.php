<?php echo $__env->make('company::layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php


    if($login_details->status == "active"){
    $check = "checked";
    }
    else{
        $check = "";
    }

?>
<div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">

                <div class="row mt-4">
                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Edit Passenger</h4>
                                <?php if(Session::has('success')): ?> <div class="alert alert-success mt-2 mb-2"><?php echo e(Session::get('success')); ?></li></div><?php endif; ?>
                                <?php if(Session::has('fail')): ?> <div class="alert alert-danger mt-2 mb-2"><?php echo e(Session::get('fail')); ?></li></div><?php endif; ?>
                            </div><!--end card-header-->
                            <div class="card-body">
                                <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">First Name</label>
                                        <input type="text" value="<?php echo e($other_details->first_name); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="first_name">
                                        <?php if($errors->has("first_name")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('first_name')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Last Name</label>
                                        <input type="text" value="<?php echo e($other_details->last_name); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="last_name">
                                        <?php if($errors->has("last_name")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('last_name')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Phone No</label>
                                        <input type="text" value="<?php echo e($other_details->phone_number); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="phone_number">
                                        <?php if($errors->has("phone_number")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('phone_number')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Royalty Deduction (%)</label>
                                        <input type="number" value="<?php echo e($other_details->royalty_deduction); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="royalty_deduction">
                                        <?php if($errors->has("royalty_deduction")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('royalty_deduction')); ?></li></div><?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1">Email</label>
                                        <input type="email" value="<?php echo e($login_details->email); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
                                        <?php if($errors->has("email")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('email')); ?></li></div><?php endif; ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" name="password">
                                        <?php if($errors->has("password")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('password')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1">Confirm Password</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" name="password_confirmation">
                                        <?php if($errors->has("password_confirmation")): ?> <div class="alert alert-danger mt-2"><?php echo e($errors->first('password_confirmation')); ?></li></div><?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="InlineCheckbox" data-parsley-multiple="groups" data-parsley-mincheck="2" name="status" <?php echo e($check); ?>>
                                            <label class="custom-control-label" for="InlineCheckbox">Active Passenger</label>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-de-primary">Submit</button>

                                </form>
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
    </div><!-- container -->
    <?php echo $__env->make('company::layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\railway-management\Modules/Company\Resources/views/edit_passenger.blade.php ENDPATH**/ ?>